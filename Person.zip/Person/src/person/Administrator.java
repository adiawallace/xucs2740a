/*
 *
 */

package person;


public class Administrator extends Person  {
    private String administratorName;
    private String administratorAddress;
    private String administratorDateOfBirth;
    private String administratorPosition;
    
    public Administrator(){
        administratorName = "Jane Doe";
        administratorAddress = "1234 Street";
        administratorDateOfBirth = "1/1/1111";
        administratorPosition = "Techincian";
    }
    
    public Administrator(String name, String address, String date, String 
            position){
        administratorName = name;
        administratorAddress = address;
        administratorDateOfBirth = date;
        administratorPosition = position;
    }
    
    public String getAdministratorName(){
        return administratorName;
    }
    
    public String getAdministratorAddress(){
        return administratorAddress;
    }

    public String getAdministratorDateOfDate(){
        return administratorDateOfBirth;
    }
    
     public String getAdministratorPosition(){
        return administratorPosition;
    }
    
    public void setAdministratorName(String name){
        administratorName = name;
    }
    
    public void setAdministratorAddress(String address){
        administratorAddress = address;
    }
    
    public void setAdministratorDateOFBirth(String date){
        administratorDateOfBirth = date;
    }
    
    public void setAdministratorPosition(String position){
        administratorPosition = position;
    }
    
    public String AdministratorInfo(){
        return "Administrator Name " +  administratorName + "Date of Birth " +
                administratorDateOfBirth + "Administrator Address " + 
                administratorAddress + "Administrator Position " + 
                administratorPosition;
    }    
}
