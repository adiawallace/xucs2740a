/*
 *
 */

package person;


public class Person {

   
    public static void main(String[] args) {
        Student newStudent = new Student();
        Administrator newAdmin = new Administrator();
        Faculty newFaculty = new Faculty();
    }
    
}
