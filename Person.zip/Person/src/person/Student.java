/*
 * 
 *
 */

package person;

public class Student extends Person {
      
    private String studentName;
    private String studentAddress;
    private String studentDateOfBirth;
    private String studentMajor;
    
    public Student(){
        studentName = "Jane Doe";
        studentAddress = "1234 Street";
        studentDateOfBirth = "1/1/1111";
        studentMajor = "Computer Science";
    }
    
    public Student(String name, String address, String date, String major){
        studentName = name;
        studentAddress = address;
        studentDateOfBirth = date;
        studentMajor = major;
    }
    
    public String getStudentName(){
        return studentName;
    }
    
    public String getStudentAddress(){
        return studentAddress;
    }

    public String getStudentDateOfDate(){
        return studentDateOfBirth;
    }
    
    public String getStudentMajor(){
        return studentMajor;
    }
    
    public void setStudentName(String name){
        studentName = name;
    }
    
    public void setStudentAddress(String address){
        studentAddress = address;
    }
    
    public void setStudentDateOFBirth(String date){
        studentDateOfBirth = date;
    }
    
    public void setStudentMajor(String major){
        studentMajor = major;
    }
    
    public String studentInfo(){
        return "Student Name " + studentName + "Date of Birth " +
                studentDateOfBirth + "Student Address " + studentAddress +
                "Student Major " + studentMajor;
    }    
}
