/*
 *
 */

package person;

public class Faculty extends Person {
    private String facultyName;
    private String facultyAddress;
    private String facultyDateOfBirth;
    private String facultyDepartment;
    private String facultyPosition;
    
    public Faculty(){
        facultyName = "John Doe";
        facultyAddress = "1234 Street";
        facultyDateOfBirth = "1/1/1111";
        facultyDepartment = "Computer Science";
        facultyPosition = "Professor";
    }
    
     public Faculty(String name, String address, String date, 
             String department, String position){
        facultyName = name;
        facultyAddress = address;
        facultyDateOfBirth = date;
        facultyDepartment = department;
        facultyPosition = position;
    }
     
     public String getFacultyName(){
        return facultyName;
    }
    
    public String getFacultyAddress(){
        return facultyAddress;
    }

    public String getFacultyDateOfDate(){
        return facultyDateOfBirth;
    }
    
    public String getFacultyDepartment(){
        return facultyDepartment;
    }
    
     public String getFacultyPosition(){
        return facultyPosition;
    }
    
    public void setFacultyName(String name){
        facultyName = name;
    }
    
    public void setFacultyAddress(String address){
        facultyAddress = address;
    }
    
    public void setFacultyDateOFBirth(String date){
        facultyDateOfBirth = date;
    }
    
    public void setFacultyDepartment(String department){
        facultyDepartment = department;
    }
    
    public void setFacultyPosition(String position){
        facultyPosition = position;
    }
    
    public String FacultyInfo(){
        return "Faculty Name " +  facultyName + "Date of Birth " +
                facultyDateOfBirth + "Faculty Address " + facultyAddress + 
                "Faculty Department " + facultyDepartment + "Faculty Position " 
                + facultyPosition;
    }    
}
